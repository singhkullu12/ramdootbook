<?php
$lang['login_login']='Login';
$lang['login_username']='Username';
$lang['login_password']='Password';
$lang['login_keep_me']='Keep me signed in';
$lang['login_invalid_username_and_password']='Invalid username/password';
$lang['login_welcome_message']='Sign in to your account';
$lang['login_message']='Please enter your name and password to log in.';

$lang['login_forgot']='I forgot my password';
$lang['login_forgot_msg']='Forget Password?';
$lang['login_reset_msg']='Enter your e-mail address below to reset your password.';
?>